<?php
if ( ! defined( 'WPINC' ) ) {
	exit;
}
return json_decode( '{"token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE3NzQxMTg4MTgsInVzZXJuYW1lIjoibmJzdHVwIiwic2l0ZV9wYXRoIjoiL2hvbWUvbmJzdHVwL3B1YmxpY19odG1sIn0.85ON0__G4oGnAl4id3YHpLAyNqaMta3GROaBxBReQbQ"}', true );