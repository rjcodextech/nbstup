<?php
if ( ! defined( 'WPINC' ) ) {
	exit;
}
return json_decode( '{"lastScanTimestamp": 1771598945, "nextScanTimestamp": 1773955800.0, "username": "nbstup", "malware": [], "config": {"MALWARE_SCANNING": {"enable_scan_cpanel": true, "default_action": "cleanup"}, "PROACTIVE_DEFENCE": {"blamer": true}}, "license": {"status": false, "upgrade_url": null, "upgrade_url_360": null, "redirect_url": null}}', true );